#!/usr/bin/env bash

set -euo pipefail

# -------------------------
# Concrete defaults
# -------------------------
REQUIRED_PACKAGES=(ros-humble-isaac-ros-visual-slam ros-humble-isaac-ros-examples ros-humble-isaac-ros-realsense)
SESSION_ROS_DOMAIN=1
DEFAULT_LAUNCH_PACKAGE="vslam"
DEFAULT_LAUNCH_FILE="isaac_ros_vslam_realsense.py"

# -------------------------
# Logging helpers
# -------------------------
log_info()  { printf '\e[1;34m[INFO]\e[0m %s\n' "$*"; }
log_warn()  { printf '\e[1;33m[WARN]\e[0m %s\n' "$*" >&2; }
log_error() { printf '\e[1;31m[ERR]\e[0m %s\n' "$*" >&2; }

# -------------------------
# Privilege utilities
# -------------------------
ensure_sudo_available() {
  if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
      SUDO_CMD="sudo"
    else
      log_error "Script requires privilege escalation to install packages but 'sudo' is not available."
      exit 1
    fi
  else
    SUDO_CMD=""
  fi
}

apt_update_if_needed() {
  log_info "Refreshing apt package index..."
  $SUDO_CMD apt-get update -y
}

is_pkg_installed() {
  dpkg -s "$1" >/dev/null 2>&1
}

install_required_pkgs() {
  local to_install=()
  for p in "${REQUIRED_PACKAGES[@]}"; do
    if is_pkg_installed "$p"; then
      log_info "Already installed: $p"
    else
      to_install+=("$p")
    fi
  done

  if [ "${#to_install[@]}" -eq 0 ]; then
    log_info "All required packages are already installed."
    return 0
  fi

  apt_update_if_needed
  log_info "Installing: ${to_install[*]}"
  $SUDO_CMD apt-get install -y "${to_install[@]}"
}

# -------------------------
# ROS domain handling
# -------------------------
set_ros_domain() {
  export ROS_DOMAIN_ID=${SESSION_ROS_DOMAIN}
  log_info "ROS_DOMAIN_ID set to ${ROS_DOMAIN_ID} for this session."
}

# -------------------------
# Try to run via ros2 CLI
# -------------------------
attempt_ros2_launch() {
  log_info "Attempting: ros2 launch ${DEFAULT_LAUNCH_PACKAGE} ${DEFAULT_LAUNCH_FILE}"
  if ! command -v ros2 >/dev/null 2>&1; then
    log_warn "ros2 CLI not found in PATH."
    return 1
  fi

  if ros2 launch "${DEFAULT_LAUNCH_PACKAGE}" "${DEFAULT_LAUNCH_FILE}"; then
    log_info "ros2 launch completed successfully."
    return 0
  else
    log_warn "ros2 launch failed or exited non-zero; will try fallback."
    return 1
  fi
}

# -------------------------
# Fallback: import launch file as Python module and run LaunchService
# -------------------------
python_launch_fallback() {
  log_info "Attempting Python fallback launch (imports local launch file)."

  if ! command -v python3 >/dev/null 2>&1; then
    log_error "python3 not available; cannot perform fallback."
    return 1
  fi

  python3 - <<'PYLAUNCH' || return 1
import importlib.util, sys, os
from pathlib import Path

LAUNCH_FILE = os.path.join(os.getcwd(), "isaac_ros_vslam_realsense.py")
if not Path(LAUNCH_FILE).exists():
    print("[fallback] Launch file not found:", LAUNCH_FILE, file=sys.stderr)
    sys.exit(2)

spec = importlib.util.spec_from_file_location("vslam_launch_module", LAUNCH_FILE)
if spec is None or spec.loader is None:
    print("[fallback] Could not load launch file module spec.", file=sys.stderr)
    sys.exit(3)

mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

if not hasattr(mod, "generate_launch_description"):
    print("[fallback] Module does not expose generate_launch_description()", file=sys.stderr)
    sys.exit(4)

ld = mod.generate_launch_description()

try:
    from launch import LaunchService
    ls = LaunchService()
    # LaunchService API differs between versions; try include, else add_action
    try:
        ls.include_launch_description(ld)
    except Exception:
        ls.add_action(ld)
    ls.run()
except Exception as e:
    print("[fallback] LaunchService.run() failed:", repr(e), file=sys.stderr)
    sys.exit(5)
PYLAUNCH

  return $?
}

# -------------------------
# Entrypoint
# -------------------------
main() {
  ensure_sudo_available
  install_required_pkgs || log_warn "Package installation step reported issues; proceeding to launch attempts."

  set_ros_domain

  if attempt_ros2_launch; then
    return 0
  fi

  if python_launch_fallback; then
    log_info "Fallback Python-based launch completed successfully."
    return 0
  fi

  log_error "All launch methods failed. Ensure:
  * ROS2 Humble is installed and sourced (e.g. 'source /opt/ros/humble/setup.bash'),
  * the package '${DEFAULT_LAUNCH_PACKAGE}' is available to ros2, or
  * the file '${DEFAULT_LAUNCH_FILE}' exists in the current working directory and defines generate_launch_description()."
  exit 1
}

main "$@"
