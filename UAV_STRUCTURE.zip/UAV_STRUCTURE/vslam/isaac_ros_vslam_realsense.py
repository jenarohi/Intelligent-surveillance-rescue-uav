import launch
from launch_ros.actions import Node, ComposableNodeContainer
from launch_ros.descriptions import ComposableNode


def _camera_node() -> Node:
    """
    RealSense node configured for IMU + two IR streams; color/depth disabled.
    Parameters deliberately preserve the same runtime behavior as the original.
    """
    params = {
        "enable_infra1": True,
        "enable_infra2": True,
        "enable_color": False,
        "enable_depth": False,
        "depth_module.emitter_enabled": 0,
        "depth_module.profile": "640x360x90",
        "enable_gyro": True,
        "enable_accel": True,
        "gyro_fps": 200,
        "accel_fps": 200,
        "unite_imu_method": 2,
    }

    return Node(
        package="realsense2_camera",
        executable="realsense2_camera_node",
        name="camera",
        namespace="camera",
        parameters=[params],
        output="screen",
    )


def _visual_slam_container() -> ComposableNodeContainer:
    """
    Container hosting the Isaac ROS Visual SLAM composable with identical parameters
    and remappings to the original launch description.
    """
    slam_params = {
        "enable_image_denoising": False,
        "rectified_images": True,
        "enable_imu_fusion": True,
        "gyro_noise_density": 0.000129,
        "gyro_random_walk": 0.0000101,
        "accel_noise_density": 0.00101,
        "accel_random_walk": 0.00010,
        "calibration_frequency": 200.0,
        "image_jitter_threshold_ms": 22.0,
        "base_frame": "camera_link",
        "imu_frame": "camera_gyro_optical_frame",
        "enable_slam_visualization": True,
        "enable_landmarks_view": True,
        "enable_observations_view": True,
        "camera_optical_frames": [
            "camera_infra1_optical_frame",
            "camera_infra2_optical_frame",
        ],
    }

    remappings = [
        ("visual_slam/image_0", "camera/infra1/image_rect_raw"),
        ("visual_slam/camera_info_0", "camera/infra1/camera_info"),
        ("visual_slam/image_1", "camera/infra2/image_rect_raw"),
        ("visual_slam/camera_info_1", "camera/infra2/camera_info"),
        ("visual_slam/imu", "camera/imu"),
    ]

    comp = ComposableNode(
        package="isaac_ros_visual_slam",
        plugin="nvidia::isaac_ros::visual_slam::VisualSlamNode",
        name="visual_slam_node",
        parameters=[slam_params],
        remappings=remappings,
    )

    return ComposableNodeContainer(
        name="visual_slam_container",
        package="rclcpp_components",
        executable="component_container",
        composable_node_descriptions=[comp],
        output="screen",
    )


def generate_launch_description() -> launch.LaunchDescription:
    """
    Assemble launch description: both the SLAM container and RealSense camera node
    are launched. Order does not alter behavior.
    """
    slam = _visual_slam_container()
    cam = _camera_node()
    return launch.LaunchDescription([slam, cam])


if __name__ == "__main__":
    ld = generate_launch_description()
    print(f"[debug] generated launch description with {len(ld.entities)} entities")
