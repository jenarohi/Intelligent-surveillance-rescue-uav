#!/usr/bin/env python3
"""
Launcher: bridge Visual SLAM -> PX4 (via MAVROS) and start mavrospy pattern runner.

Behavior preserved:
  - includes MAVROS px4.launch (configurable fcu_url)
  - relays /visual_slam/tracking/vo_pose_covariance -> /mavros/vision_pose/pose_cov
  - launches mavrospy executable named "<pattern>_py" with parameter {"vision": True}
"""

from __future__ import annotations

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import AnyLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, TextSubstitution
from launch_ros.actions import Node


def _px4_launch_file_path() -> str:
    """Resolve the px4.launch file installed with mavros (same location as original)."""
    return os.path.expanduser("~/ros2_ws/install/mavros/share/mavros/launch/px4.launch")


def _include_px4_launch(fcu: LaunchConfiguration) -> IncludeLaunchDescription:
    """Return an IncludeLaunchDescription that passes the FCU URL into the px4.launch file."""
    path = _px4_launch_file_path()
    return IncludeLaunchDescription(
        AnyLaunchDescriptionSource(path),
        launch_arguments={"fcu_url": fcu}.items(),
    )


def _relay_vio_topic() -> Node:
    """
    Relay node using topic_tools/relay to forward Visual SLAM pose messages
    into MAVROS' vision pose topic expected by PX4.
    """
    source_topic = "/visual_slam/tracking/vo_pose_covariance"
    target_topic = "/mavros/vision_pose/pose_cov"
    return Node(
        package="topic_tools",
        executable="relay",
        name="vslam_to_mavros_relay",
        output="screen",
        arguments=[source_topic, target_topic],
    )


def _mavrospy_node_for_pattern(pattern_cfg: LaunchConfiguration) -> Node:
    """
    Launch mavrospy executable built by concatenating the provided pattern name
    with the suffix '_py' (identical runtime effect to original).
    """
    exec_name = [pattern_cfg, TextSubstitution(text="_py")]
    return Node(
        package="mavrospy",
        executable=exec_name,
        name="mavrospy_runner",
        output="screen",
        parameters=[{"vision": True}],
    )


def generate_launch_description() -> LaunchDescription:
    """
    Assemble the full launch description. Argument defaults and ordering preserve
    the same runtime behavior as the original file.
    """
    # launch arguments (same defaults)
    fcu_arg = DeclareLaunchArgument(
        "fcu_url",
        default_value="/dev/ttyUSB0:921600",
        description="Serial device and baud for PX4 FMU (e.g. /dev/ttyUSB0:921600)",
    )

    pattern_arg = DeclareLaunchArgument(
        "pattern",
        default_value="square",
        description="Flight pattern name; mavrospy executable will be '<pattern>_py'",
    )

    fcu_cfg = LaunchConfiguration("fcu_url")
    pattern_cfg = LaunchConfiguration("pattern")

    px4_include = _include_px4_launch(fcu_cfg)
    relay = _relay_vio_topic()
    mavrospy = _mavrospy_node_for_pattern(pattern_cfg)

    return LaunchDescription([pattern_arg, fcu_arg, px4_include, relay, mavrospy])


if __name__ == "__main__":
    ld = generate_launch_description()
    print(f"[debug] launch description assembled with {len(ld.entities)} elements")
