#!/usr/bin/env bash


set -euo pipefail

# -------------------------
# Concrete paths / settings
# -------------------------
ROSBAG_DIR="/home/analysis/imu_rosbag"
CONFIG_TARGET="${HOME}/ros2_ws/src/allan_ros2/config/config.yaml"
WORKSPACE_ROOT="${HOME}/ros2_ws"
PKG_TO_BUILD="allan_ros2"

# -------------------------
# Find a .db3 rosbag (first match in the directory)
# -------------------------
DB3_FILE="$(find "${ROSBAG_DIR}" -maxdepth 1 -type f -name '*.db3' | head -n 1 || true)"

if [[ -z "${DB3_FILE}" ]]; then
  printf '%s\n' "No .db3 file found in ${ROSBAG_DIR}" >&2
  exit 1
fi

printf '%s\n' "Found rosbag: ${DB3_FILE}"

# -------------------------
# Overwrite the allan_ros2 config.yaml with a concrete config
# -------------------------
cat > "${CONFIG_TARGET}" <<EOF
allan_node:
  ros__parameters:
    topic: /camera/imu
    bag_path: ${DB3_FILE}
    msg_type: ros
    publish_rate: 200
    sample_rate: 200
EOF

printf '%s\n' "Wrote updated config to: ${CONFIG_TARGET}"

# -------------------------
# Build the package (colcon) and source the overlay
# -------------------------
if [[ ! -d "${WORKSPACE_ROOT}" ]]; then
  printf '%s\n' "Workspace not found at ${WORKSPACE_ROOT}" >&2
  exit 1
fi

cd "${WORKSPACE_ROOT}"

printf '%s\n' "Building package: ${PKG_TO_BUILD} ..."
if ! colcon build --packages-select "${PKG_TO_BUILD}"; then
  printf '%s\n' "colcon build failed for ${PKG_TO_BUILD}" >&2
  exit 1
fi

printf '%s\n' "Sourcing workspace overlay..."
# Use the installed setup if present; this mirrors interactive behavior.
# It's safe if the file is missing (will error if not found — keep parity with original script).
# Use bash source for current shell only.
source "${WORKSPACE_ROOT}/install/setup.bash"

printf '%s\n' "Done — configuration updated, package built and workspace sourced."
