#!/usr/bin/env bash

set -euo pipefail

# -------------------------
# Logging helpers
# -------------------------
_log()  { printf "\e[1;34m[LOG]\e[0m %s\n" "$*"; }
_fail() { printf "\e[1;31m[FAIL]\e[0m %s\n" "$*" >&2; exit 1; }

# -------------------------
# Preconditions
# -------------------------
ensure_ros2_sourced() {
    if ! command -v ros2 >/dev/null 2>&1; then
        _fail "ros2 executable not found. Please source ROS 2 Humble (e.g. source /opt/ros/humble/setup.bash)."
    fi
}

# -------------------------
# RealSense launch wrapper
# -------------------------
start_realsense_node() {
    _log "Starting RealSense (IMU + Infrared) via ros2 launch..."

    # Keep the same launchfile and parameter settings as the original script.
    # These flags enable the two IR streams, disable color/depth, and configure IMU rates.
    ros2 launch realsense2_camera rs_launch.py \
        enable_infra1:=true \
        enable_infra2:=true \
        enable_color:=false \
        enable_depth:=false \
        depth_module.emitter_enabled:=0 \
        depth_module.profile:=640x360x90 \
        enable_gyro:=true \
        enable_accel:=true \
        gyro_fps:=200 \
        accel_fps:=200 \
        unite_imu_method:=2
}

# -------------------------
# Entrypoint
# -------------------------
main() {
    ensure_ros2_sourced
    start_realsense_node
}

main "$@"
