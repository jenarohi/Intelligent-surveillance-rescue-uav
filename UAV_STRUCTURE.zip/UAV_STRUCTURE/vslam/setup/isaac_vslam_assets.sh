#!/usr/bin/env bash


# -------------------------
# Concrete settings
# -------------------------
NGC_ORG="nvidia"
NGC_TEAM="isaac"
NGC_RESOURCE="isaac_ros_visual_slam_assets"
NGC_FILENAME="quickstart.tar.gz"

# Target workspace for assets (concrete default)
ISAAC_ROS_WS="${HOME}/isaac_ros_ws"

# Version constraint (concrete)
REQ_MAJOR=3
REQ_MINOR=2

# API page size
PAGE_SIZE=100

# -------------------------
# Helpers
# -------------------------
info(){ printf '[INFO] %s\n' "$*"; }
warn(){ printf '[WARN] %s\n' "$*" >&2; }
fail(){ printf '[ERROR] %s\n' "$*" >&2; exit 1; }

# -------------------------
# Compose API URL
# -------------------------
VERSIONS_API="https://catalog.ngc.nvidia.com/api/resources/versions?orgName=${NGC_ORG}&teamName=${NGC_TEAM}&name=${NGC_RESOURCE}&isPublic=true&pageNumber=0&pageSize=${PAGE_SIZE}&sortOrder=CREATED_DATE_DESC"

info "Querying NGC for available versions of ${NGC_RESOURCE}..."
versions_json=$(curl -sSf "${VERSIONS_API}") || fail "Failed to query NGC versions API."

# -------------------------
# Pick best semantic version: major == REQ_MAJOR and minor <= REQ_MINOR
# -------------------------
LATEST_VER=$(printf '%s' "${versions_json}" | jq -r --argjson MAJOR "${REQ_MAJOR}" --argjson MINOR "${REQ_MINOR}" '
  .recipeVersions[]
  | .versionId
  | select(test("^[0-9]+\\.[0-9]+\\.[0-9]+$"))
  | split(".") as $parts
  | {major: ($parts[0]|tonumber), minor: ($parts[1]|tonumber), patch: ($parts[2]|tonumber), raw: join(".")}
  | select(.major == $MAJOR and .minor <= $MINOR)
  | .raw
' | sort -V | tail -n 1 || true)

if [[ -z "${LATEST_VER}" ]]; then
  info "No matching version found for Isaac ROS ${REQ_MAJOR}.${REQ_MINOR}."
  info "Available semantic versions reported by NGC:"
  printf '%s\n' "${versions_json}" | jq -r '.recipeVersions[].versionId' | sort -V || true
  exit 0
fi

info "Selected version: ${LATEST_VER}"

# -------------------------
# Prepare destination and temp file
# -------------------------
ASSETS_DIR="${ISAAC_ROS_WS}/isaac_ros_assets"
mkdir -p "${ASSETS_DIR}"

TMP_FILE="$(mktemp --tmpdir="$(pwd)" tmp_${NGC_FILENAME}.XXXXXX)"
trap 'rm -f "${TMP_FILE}"' EXIT

FILE_URL="https://api.ngc.nvidia.com/v2/resources/${NGC_ORG}/${NGC_TEAM}/${NGC_RESOURCE}/versions/${LATEST_VER}/files/${NGC_FILENAME}"

info "Downloading ${NGC_FILENAME} from NGC (version ${LATEST_VER})..."
if ! curl -fL --output "${TMP_FILE}" "${FILE_URL}"; then
  fail "Download failed for ${FILE_URL}"
fi
info "Downloaded to temporary file: ${TMP_FILE}"

# -------------------------
# Extract and cleanup
# -------------------------
info "Extracting ${NGC_FILENAME} into ${ASSETS_DIR}..."
if tar -xzf "${TMP_FILE}" -C "${ASSETS_DIR}"; then
  info "Extraction succeeded."
  rm -f "${TMP_FILE}"
  trap - EXIT
else
  fail "Extraction failed; inspect ${TMP_FILE} for details."
fi

info "Asset install completed. Files extracted to: ${ASSETS_DIR}"
