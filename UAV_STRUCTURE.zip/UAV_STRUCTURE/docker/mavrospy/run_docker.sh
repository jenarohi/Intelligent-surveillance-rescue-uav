#!/usr/bin/env bash

set -euo pipefail

# -------------------------
# Concrete configuration
# -------------------------
IMG_NAME="mavrospy-vslam"
IMG_TAG="latest"
DOCKERFILE="./Dockerfile"
CNTR_NAME="mavrospy-vslam-container"
SERIAL_DEVICE="/dev/ttyTHS1"

# -------------------------
# Helpers / messages
# -------------------------
info(){ printf '[INFO] %s\n' "$*"; }
fail(){ printf '[ERROR] %s\n' "$*" >&2; exit 1; }

# -------------------------
# Basic safety: don't run as root
# -------------------------
if [[ "$(id -u)" -eq 0 ]]; then
  fail "This script must not be run as root. Re-run as a regular user."
fi

CURRENT_USER="$(id -un)"

# Ensure the user is in the 'docker' group
if ! id -nG "${CURRENT_USER}" | grep -qw docker; then
  fail "User '${CURRENT_USER}' is not in the 'docker' group. Run: sudo usermod -aG docker ${CURRENT_USER} && newgrp docker"
fi

# Quick test that docker commands work
if ! docker ps >/dev/null 2>&1; then
  fail "Docker commands are not available for this user. Verify Docker daemon is running and your group membership is active."
fi

# -------------------------
# Cleanup any exited instance with same name
# -------------------------
if docker ps -a --filter "name=^/${CNTR_NAME}\$" --filter "status=exited" --quiet | grep -q .; then
  info "Removing previously exited container '${CNTR_NAME}'..."
  docker rm "${CNTR_NAME}" >/dev/null || true
fi

# If a container with the same name is running, attach to it
if docker ps --filter "name=^/${CNTR_NAME}\$" --filter "status=running" --quiet | grep -q .; then
  info "Attaching to running container: ${CNTR_NAME}"
  docker exec -it "${CNTR_NAME}" bash
  exit 0
fi

# -------------------------
# Image helpers
# -------------------------
image_present() {
  docker image inspect "${IMG_NAME}:${IMG_TAG}" >/dev/null 2>&1
}

build_image() {
  info "Building Docker image ${IMG_NAME}:${IMG_TAG} from ${DOCKERFILE}..."
  docker build --network=host -t "${IMG_NAME}:${IMG_TAG}" -f "${DOCKERFILE}" .
}

# Build image if missing
if image_present; then
  info "Image ${IMG_NAME}:${IMG_TAG} already exists locally."
else
  info "Image ${IMG_NAME}:${IMG_TAG} not found — building now."
  build_image
  if image_present; then
    info "Image built successfully."
  else
    fail "Image build failed."
  fi
fi

# -------------------------
# Run the container
# -------------------------
info "Launching container '${CNTR_NAME}' from image ${IMG_NAME}:${IMG_TAG}..."

# Compose run args
RUN_ARGS=(
  --rm
  -it
  --name "${CNTR_NAME}"
  --device "${SERIAL_DEVICE}"
  --net=host
  --ipc=host
)

docker run "${RUN_ARGS[@]}" "${IMG_NAME}:${IMG_TAG}"
