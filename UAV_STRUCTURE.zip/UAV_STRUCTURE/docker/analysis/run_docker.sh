#!/usr/bin/env bash

set -euo pipefail

# -------------------------
# Concrete defaults (user-editable within script)
# -------------------------
IMAGE="analysis"
TAG="latest"
DOCKERFILE_PATH="./Dockerfile"
CONTAINER="analysis-container"
FLAG_FORCE_REBUILD=false

# Host -> container mounts (concrete absolute paths)
HOST_IMU="/home/analysis/VSLAM-UAV/docker/analysis/imu_rosbag"
HOST_CFG="/home/analysis/VSLAM-UAV/docker/analysis/cfg.yaml"

# Target paths inside the container (concrete)
TARGET_IMU="/home/analysis/imu_rosbag"
TARGET_CFG="/home/analysis/ros2_ws/src/motion_capture_tracking/motion_capture_tracking/config/cfg.yaml"

# Extra mounts may be appended here, e.g. EXTRA_ARGS+=("-v" "/tmp:/tmp")
EXTRA_ARGS=()

# ROS domain id (explicit)
ROS_DOMAIN_ID=1

# -------------------------
# Parse args
# -------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --rebuild) FLAG_FORCE_REBUILD=true; shift ;;
    *) shift ;;
  esac
done

# -------------------------
# Logging helpers
# -------------------------
info()  { printf '%s\n' "$*"; }
warn()  { printf 'WARN: %s\n' "$*" >&2; }
fatal() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

# -------------------------
# Safety checks
# -------------------------
if [[ "$(id -u)" -eq 0 ]]; then
  fatal "Refusing to run as root. Re-run as your normal user."
fi

CURRENT_USER="$(id -un)"

if ! id -nG "${CURRENT_USER}" | grep -qw docker; then
  fatal "User '${CURRENT_USER}' is not in the docker group. Run: sudo usermod -aG docker ${CURRENT_USER} && newgrp docker"
fi

if ! docker info > /dev/null 2>&1; then
  fatal "Docker daemon not reachable for this user. Ensure Docker is running and accessible."
fi

# Remove old exited container of same name (if present)
if docker ps -a --filter "name=^/${CONTAINER}\$" --filter "status=exited" --quiet | grep -q .; then
  info "Cleaning up stale container named ${CONTAINER}..."
  docker rm "${CONTAINER}" >/dev/null || true
fi

# If container running, attach a shell and exit
if docker ps --filter "name=^/${CONTAINER}\$" --filter "status=running" --quiet | grep -q .; then
  info "Container ${CONTAINER} already running — attaching shell."
  docker exec -it "${CONTAINER}" bash
  exit 0
fi

# -------------------------
# Image management utilities
# -------------------------
image_exists() {
  docker image inspect "${IMAGE}:${TAG}" >/dev/null 2>&1
}

build_with_cache() {
  info "Building image ${IMAGE}:${TAG} (using cache) from ${DOCKERFILE_PATH}..."
  docker build --network=host -t "${IMAGE}:${TAG}" -f "${DOCKERFILE_PATH}" .
}

build_no_cache() {
  info "Building image ${IMAGE}:${TAG} (no cache) from ${DOCKERFILE_PATH}..."
  docker build --no-cache --network=host -t "${IMAGE}:${TAG}" -f "${DOCKERFILE_PATH}" .
}

# Build if missing
if image_exists; then
  info "Docker image ${IMAGE}:${TAG} found locally."
else
  info "Docker image ${IMAGE}:${TAG} not found — building now."
  build_with_cache
  if image_exists; then
    info "Image build succeeded."
  else
    fatal "Image build failed."
  fi
fi

# Force rebuild when requested
if [[ "${FLAG_FORCE_REBUILD}" == true ]]; then
  build_no_cache
  if image_exists; then
    info "Rebuild successful."
  else
    fatal "Rebuild failed."
  fi
fi

# -------------------------
# X11 / Xauthority for GUI (best-effort)
# -------------------------
XSOCK="/tmp/.X11-unix"
XAUTH="/tmp/.docker.xauth"
DISPLAY="${DISPLAY:-:0}"

if [[ -z "${DISPLAY}" ]]; then
  warn "DISPLAY not set; GUI applications inside the container will not be available."
else
  if [[ ! -f "${XAUTH}" ]]; then
    touch "${XAUTH}"
    xauth_entries=$(xauth nlist "${DISPLAY}" 2>/dev/null || true)
    if [[ -n "${xauth_entries}" ]]; then
      echo "${xauth_entries}" | sed -e 's/^..../ffff/' | xauth -f "${XAUTH}" nmerge - >/dev/null 2>&1 || true
      chmod a+r "${XAUTH}" || true
    else
      warn "Could not extract xauth for ${DISPLAY}; GUI access may fail."
    fi
  fi
fi

# -------------------------
# Ensure host mount points exist (helpful messages + best-effort creation)
# -------------------------
if [[ ! -d "${HOST_IMU}" ]]; then
  warn "Host IMU directory missing: ${HOST_IMU}"
  info "Attempting to create ${HOST_IMU}..."
  mkdir -p "${HOST_IMU}" || warn "Failed to create ${HOST_IMU}; check permissions."
fi

if [[ ! -f "${HOST_CFG}" ]]; then
  warn "Host cfg.yaml not found at: ${HOST_CFG}"
  info "Create or populate this file if your containerized nodes require it."
fi

# -------------------------
# Compose docker run options
# -------------------------
info "Launching container ${IMAGE}:${TAG} as ${CONTAINER}..."

UID_VAL="$(id -u)"
GID_VAL="$(id -g)"

RUN_PARAMS=(
  --rm
  --net=host
  --name "${CONTAINER}"
  -e "DISPLAY=${DISPLAY}"
  -e "ROS_DOMAIN_ID=${ROS_DOMAIN_ID}"
  -v "${XSOCK}:${XSOCK}:rw"
)

# Add XAUTH if present
if [[ -f "${XAUTH}" ]]; then
  RUN_PARAMS+=( -e "XAUTHORITY=${XAUTH}" -v "${XAUTH}:${XAUTH}:rw" )
fi

# Mount application data
RUN_PARAMS+=( -v "${HOST_IMU}:${TARGET_IMU}:rw" )
RUN_PARAMS+=( -v "${HOST_CFG}:${TARGET_CFG}:rw" )

# Append any user-specified extra mounts
if [[ ${#EXTRA_ARGS[@]} -gt 0 ]]; then
  RUN_PARAMS+=( "${EXTRA_ARGS[@]}" )
fi

# Ensure proper working dir and user mapping to preserve file ownership on mounts
RUN_PARAMS+=( -w "/home/analysis" -u "${UID_VAL}:${GID_VAL}" )

# Final execution: source ROS (if present) and hand control to interactive bash
docker run -it "${RUN_PARAMS[@]}" "${IMAGE}:${TAG}" /bin/bash -lc "source /opt/ros/humble/setup.bash 2>/dev/null || true; exec bash"

# End of script
