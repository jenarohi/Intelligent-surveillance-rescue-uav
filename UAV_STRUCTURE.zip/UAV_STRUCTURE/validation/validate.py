#!/usr/bin/env python3
"""
vslam_validation.py

Loads ground-truth and VSLAM CSVs, aligns timestamps, computes RMSE for
position (ATE) and yaw, and plots multiple diagnostic figures.

Behavior is unchanged from the original script: same numeric ops,
same CSV expectations, same plots and printed RMSE values.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation


# -------------------------
# IO helpers
# -------------------------
def read_validation_csvs(folder: Path):
    gt_file = folder / "ground_truth.csv"
    vslam_file = folder / "vslam_estimates.csv"
    if not gt_file.exists() or not vslam_file.exists():
        raise FileNotFoundError(f"Required CSVs not found in {folder!s}")
    gt_df = pd.read_csv(gt_file)
    vslam_df = pd.read_csv(vslam_file)
    return gt_df, vslam_df


# -------------------------
# Preprocessing utilities
# -------------------------
def remove_initial_offset(gt_df: pd.DataFrame, n_samples: int = 200) -> pd.DataFrame:
    """
    Subtract the average of the first n_samples from the ground-truth XYZ
    so trajectories start near the origin.
    """
    n = min(len(gt_df), n_samples)
    mean_x = gt_df["gt_position_x"].iloc[:n].mean()
    mean_y = gt_df["gt_position_y"].iloc[:n].mean()
    mean_z = gt_df["gt_position_z"].iloc[:n].mean()

    gt_df = gt_df.copy()
    gt_df["gt_position_x"] = gt_df["gt_position_x"] - mean_x
    gt_df["gt_position_y"] = gt_df["gt_position_y"] - mean_y
    gt_df["gt_position_z"] = gt_df["gt_position_z"] - mean_z
    return gt_df


def quaternions_to_euler_deg(df: pd.DataFrame, prefix: str) -> pd.DataFrame:
    """
    Convert quaternion columns with given prefix into roll,pitch,yaw degrees.
    Expects columns: {prefix}_orientation_x/y/z/w
    """
    qx = df[f"{prefix}_orientation_x"].values
    qy = df[f"{prefix}_orientation_y"].values
    qz = df[f"{prefix}_orientation_z"].values
    qw = df[f"{prefix}_orientation_w"].values
    quat_stack = np.column_stack([qx, qy, qz, qw])
    rot = Rotation.from_quat(quat_stack)
    eulers = rot.as_euler("xyz", degrees=True)
    cols = [f"{prefix}_roll", f"{prefix}_pitch", f"{prefix}_yaw"]
    return pd.DataFrame(eulers, columns=cols)


def median_smooth_yaw(gt_df: pd.DataFrame, wnd: int = 150) -> pd.DataFrame:
    """
    Add a smoothed yaw column based on a centered rolling median.
    Back/forward fill to handle edges.
    """
    df = gt_df.copy()
    sm = df["gt_yaw"].rolling(window=wnd, center=True).median()
    sm = sm.bfill().ffill()
    df["gt_yaw_smoothed"] = sm
    return df


def construct_time_columns(gt_df: pd.DataFrame, vslam_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build floating-point time columns (seconds) and normalize both series to start at 0.
    """
    gt = gt_df.copy()
    vs = vslam_df.copy()

    gt["gt_time"] = gt["gt_secs"] + gt["gt_nsecs"] / 1e9
    vs["vslam_time"] = vs["vslam_secs"] + vs["vslam_nsecs"] / 1e9

    gt["gt_time"] = gt["gt_time"] - gt["gt_time"].iloc[0]
    vs["vslam_time"] = vs["vslam_time"] - vs["vslam_time"].iloc[0]

    return gt, vs


# -------------------------
# Error / interpolation computations
# -------------------------
def evaluate_position_rmse(gt_df: pd.DataFrame, vslam_df: pd.DataFrame):
    """
    Interpolate ground-truth position to VSLAM timestamps and compute ATE RMSE.
    Returns (rmse, gt_interpolated_positions, vslam_positions, vslam_time_array)
    """
    gt_t = gt_df["gt_time"].values
    vs_t = vslam_df["vslam_time"].values

    interp_x = interp1d(gt_t, gt_df["gt_position_x"].values, kind="linear", fill_value="extrapolate")
    interp_y = interp1d(gt_t, gt_df["gt_position_y"].values, kind="linear", fill_value="extrapolate")
    interp_z = interp1d(gt_t, gt_df["gt_position_z"].values, kind="linear", fill_value="extrapolate")

    gt_interp = np.stack([interp_x(vs_t), interp_y(vs_t), interp_z(vs_t)], axis=1)
    vslam_pos = np.stack(
        [vslam_df["vslam_position_x"].values, vslam_df["vslam_position_y"].values, vslam_df["vslam_position_z"].values], axis=1
    )

    errors = np.linalg.norm(gt_interp - vslam_pos, axis=1)
    rmse = np.sqrt(np.mean(errors ** 2))
    return rmse, gt_interp, vslam_pos, vs_t


def evaluate_yaw_rmse(gt_df: pd.DataFrame, vslam_df: pd.DataFrame, vslam_time: np.ndarray):
    """
    Interpolate smoothed ground-truth yaw to VSLAM times and compute yaw RMSE.
    Returns (rmse_yaw, gt_yaw_at_vslam, vslam_yaw_array)
    """
    interp_yaw = interp1d(gt_df["gt_time"].values, gt_df["gt_yaw_smoothed"].values, kind="linear", fill_value="extrapolate")
    gt_yaw_on_vs = interp_yaw(vslam_time)
    vs_yaw = vslam_df["vslam_yaw"].values
    err_yaw = gt_yaw_on_vs - vs_yaw
    rmse_yaw = np.sqrt(np.mean(err_yaw ** 2))
    return rmse_yaw, gt_yaw_on_vs, vs_yaw


# -------------------------
# Plotting
# -------------------------
def plot_diagnostics(gt_df: pd.DataFrame, vslam_df: pd.DataFrame, gt_interp: np.ndarray, vslam_pos: np.ndarray, vslam_time: np.ndarray):
    # ground truth positions
    gt_x = gt_df["gt_position_x"].values
    gt_y = gt_df["gt_position_y"].values
    gt_z = gt_df["gt_position_z"].values

    vx = vslam_pos[:, 0]
    vy = vslam_pos[:, 1]
    vz = vslam_pos[:, 2]

    # 3D trajectory
    fig = plt.figure(1, figsize=(12, 8))
    ax = plt.axes(projection="3d")
    plt.suptitle("Ground Truth vs. VSLAM Position", fontsize=16)
    ax.plot(gt_x, gt_y, gt_z)
    ax.plot(vx, vy, vz)
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.legend(["Ground Truth", "VSLAM"])

    # X vs time
    plt.figure(2, figsize=(10, 6))
    plt.plot(gt_df["gt_time"].values, gt_x)
    plt.plot(vslam_time, vx)
    plt.xlabel("Time (sec)")
    plt.ylabel("X Position (m)")
    plt.title("X Position vs. Time")
    plt.legend(["Ground Truth", "VSLAM"], loc="upper right")

    # Y vs time
    plt.figure(3, figsize=(10, 6))
    plt.plot(gt_df["gt_time"].values, gt_y)
    plt.plot(vslam_time, vy)
    plt.xlabel("Time (sec)")
    plt.ylabel("Y Position (m)")
    plt.title("Y Position vs. Time")
    plt.legend(["Ground Truth", "VSLAM"], loc="upper right")

    # Z vs time
    plt.figure(4, figsize=(10, 6))
    plt.plot(gt_df["gt_time"].values, gt_z)
    plt.plot(vslam_time, vz)
    plt.xlabel("Time (sec)")
    plt.ylabel("Z Position (m)")
    plt.title("Z Position vs. Time")
    plt.legend(["Ground Truth", "VSLAM"], loc="upper left")

    # XY top-down
    plt.figure(5, figsize=(10, 6))
    plt.plot(gt_x, gt_y)
    plt.plot(vx, vy)
    plt.xlabel("X Position (m)")
    plt.ylabel("Y Position (m)")
    plt.title("X vs Y (Top-down)")
    plt.legend(["Ground Truth", "VSLAM"], loc="upper right")

    # XZ
    plt.figure(6, figsize=(10, 6))
    plt.plot(gt_x, gt_z)
    plt.plot(vx, vz)
    plt.xlabel("X Position (m)")
    plt.ylabel("Z Position (m)")
    plt.title("X vs Z")
    plt.legend(["Ground Truth", "VSLAM"], loc="lower right")

    # yaw vs time
    plt.figure(7, figsize=(10, 6))
    plt.plot(gt_df["gt_time"].values, gt_df["gt_yaw_smoothed"].values)
    plt.plot(vslam_time, vslam_df["vslam_yaw"].values)
    plt.xlabel("Time (sec)")
    plt.ylabel("Yaw (deg)")
    plt.title("Yaw vs Time")
    plt.legend(["Ground Truth", "VSLAM"], loc="upper right")

    plt.show()


# -------------------------
# CLI and main
# -------------------------
def build_parser():
    p = argparse.ArgumentParser(description="Validate VSLAM against ground-truth CSVs.")
    p.add_argument(
        "--base",
        type=str,
        default="/home/analysis/VSLAM-UAV/validation/validation_data",
        help="Directory containing ground_truth.csv and vslam_estimates.csv",
    )
    return p


def main():
    args = build_parser().parse_args()
    base_dir = Path(args.base)

    gt_df, vslam_df = read_validation_csvs(base_dir)

    gt_df = remove_initial_offset(gt_df, n_samples=200)

    gt_eulers = quaternions_to_euler_deg(gt_df, "gt")
    gt_df = pd.concat([gt_df.reset_index(drop=True), gt_eulers.reset_index(drop=True)], axis=1)

    vslam_eulers = quaternions_to_euler_deg(vslam_df, "vslam")
    vslam_df = pd.concat([vslam_df.reset_index(drop=True), vslam_eulers.reset_index(drop=True)], axis=1)

    gt_df = median_smooth_yaw(gt_df, wnd=150)
    gt_df, vslam_df = construct_time_columns(gt_df, vslam_df)

    rmse_ate, gt_interp, vslam_pos, vslam_time = evaluate_position_rmse(gt_df, vslam_df)
    print(f"RMSE of ATE: {rmse_ate}")

    rmse_yaw, gt_yaw_interp, vs_yaw = evaluate_yaw_rmse(gt_df, vslam_df, vslam_time)
    print(f"RMSE of Yaw Error: {rmse_yaw}")

    plot_diagnostics(gt_df, vslam_df, gt_interp, vslam_pos, vslam_time)


if __name__ == "__main__":
    main()
