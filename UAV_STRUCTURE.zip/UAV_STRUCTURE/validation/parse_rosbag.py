#!/usr/bin/env python3
"""
rosbag2_to_csv.py

Reads a rosbag2 directory and extracts:
  - ground truth poses published on /poses
  - visual SLAM PoseWithCovarianceStamped on /visual_slam/tracking/vo_pose_covariance

Produces two CSVs inside the rosbag directory:
  - ground_truth.csv
  - vslam_estimates.csv

Behavior matches the original extractor: same message registration,
deserialization, CSV column names and file locations.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple

import pandas as pd
from rosbags.rosbag2 import Reader
from rosbags.typesys import Stores, get_types_from_msg, get_typestore

# Topic identifiers (kept identical to ensure unchanged behavior)
_TOPIC_GROUND_TRUTH = "/poses"
_TOPIC_VSLAM = "/visual_slam/tracking/vo_pose_covariance"



def _read_msg_file(dirpath: Path, msgname: str) -> str:
    p = dirpath / f"{msgname}.msg"
    return p.read_text()


def _assemble_custom_types() -> Dict[str, Any]:
    """
    Load local msg definitions for NamedPose and NamedPoseArray and
    return the mapping suitable for typestore.register().
    """
    base = Path("motion_capture_tracking_interfaces/msg")
    collected: Dict[str, Any] = {}

    for nm in ("NamedPose", "NamedPoseArray"):
        txt = _read_msg_file(base, nm)
        full = f"motion_capture_tracking_interfaces/msg/{nm}"
        collected.update(get_types_from_msg(txt, full))

    return collected


def build_typestore() -> object:
    """
    Create a typestore for ROS 2 Humble and register the local custom message types.
    """
    store = get_typestore(Stores.ROS2_HUMBLE)
    store.register(_assemble_custom_types())
    return store



def _flatten_namedposearray(msg) -> Dict[str, Any]:
    first = msg.poses[0].pose
    p = first.position
    q = first.orientation

    return {
        "gt_secs": msg.header.stamp.sec,
        "gt_nsecs": msg.header.stamp.nanosec,
        "gt_position_x": p.x,
        "gt_position_y": p.y,
        "gt_position_z": p.z,
        "gt_orientation_x": q.x,
        "gt_orientation_y": q.y,
        "gt_orientation_z": q.z,
        "gt_orientation_w": q.w,
    }


def _flatten_pose_with_cov(msg) -> Dict[str, Any]:
    pose = msg.pose.pose
    p = pose.position
    q = pose.orientation

    return {
        "vslam_secs": msg.header.stamp.sec,
        "vslam_nsecs": msg.header.stamp.nanosec,
        "vslam_position_x": p.x,
        "vslam_position_y": p.y,
        "vslam_position_z": p.z,
        "vslam_orientation_x": q.x,
        "vslam_orientation_y": q.y,
        "vslam_orientation_z": q.z,
        "vslam_orientation_w": q.w,
    }


# -------------------------
# Main processor
# -------------------------
@dataclass
class RosbagProcessor:
    bag_dir: Path
    typestore: object

    def iterate_and_extract(self) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Walk messages in the rosbag2 directory and collect rows for ground truth
        and vslam CSV files. Returns (gt_rows, vslam_rows).
        """
        gt_rows: List[Dict[str, Any]] = []
        vslam_rows: List[Dict[str, Any]] = []

        # Reader accepts a rosbag2 directory path
        with Reader(self.bag_dir.as_posix()) as reader:
            for connection, _, raw in reader.messages():
                topic = connection.topic

                # Deserialize using the typestore; skip messages that fail to deserialize.
                try:
                    msg = self.typestore.deserialize_cdr(raw, connection.msgtype)
                except Exception:
                    # preserve robustness: continue processing remaining messages
                    continue

                if topic == _TOPIC_GROUND_TRUTH:
                    gt_rows.append(_flatten_namedposearray(msg))
                elif topic == _TOPIC_VSLAM:
                    vslam_rows.append(_flatten_pose_with_cov(msg))

        return gt_rows, vslam_rows

    def write_csvs(self, gt: List[Dict[str, Any]], vslam: List[Dict[str, Any]]) -> None:
        """
        Write the two CSV files into the rosbag directory.
        """
        # ensure target exists (it should) but be safe
        self.bag_dir.mkdir(parents=True, exist_ok=True)

        pd.DataFrame(gt).to_csv(self.bag_dir / "ground_truth.csv", index=False)
        pd.DataFrame(vslam).to_csv(self.bag_dir / "vslam_estimates.csv", index=False)


# -------------------------
# CLI and entrypoint
# -------------------------
def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Extract GT and VSLAM CSVs from a rosbag2 directory.")
    p.add_argument(
        "--name",
        required=True,
        help="Name of the rosbag directory inside /home/analysis/VSLAM-UAV/validation",
    )
    return p


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    base = Path("/home/analysis/VSLAM-UAV/validation")
    target = base / args.name

    if not target.exists():
        raise FileNotFoundError(f"Rosbag directory does not exist: {target}")

    ts = build_typestore()
    proc = RosbagProcessor(target, ts)

    gt_rows, vslam_rows = proc.iterate_and_extract()
    proc.write_csvs(gt_rows, vslam_rows)

    print(f"Ground truth and VSLAM CSV files saved in: {target}")


if __name__ == "__main__":
    main()
